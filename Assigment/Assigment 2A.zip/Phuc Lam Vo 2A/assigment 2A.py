#-----Statement of Authorship----------------------------------------#
#
# This is an individual assessment task for QUT's teaching unit
# IFB104, "Building IT Systems". By submitting
# this code I agree that it represents my own work. I am aware of
# the University rule that a student must not act in a manner
# which constitutes academic dishonesty as stated and explained
# in QUT's Manual of Policies and Procedures, Section C/5.3
# "Academic Integrity" and Section E/2.1 "Student Code of Conduct".
#
# Put your student number here as an integer and your name as a
# character string:
#
student_number = 11912839   
student_name = "Phuc Lam Vo"
#
# NB: All files submitted for this assessable task will be subjected
# to automated plagiarism analysis using a tool such as the Measure
# of Software Similarity (http://theory.stanford.edu/~aiken/moss/).
#
#--------------------------------------------------------------------#


#-----Assessment Task 2 Description----------------------------------#
#
#  In this assessment you will combine your knowledge of Python
#  programming, and Graphical User Interface design to produce
#  a robust, interactive "app" that allows user to view 
#  data from a data source.
#
#  See the client's briefings accompanying this file for full
#  details.
#
#  Note that this assessable assignment is in multiple parts,
#  simulating incremental release of instructions by a paying
#  "client".  This single template file will be used for all parts,
#  together with some non-Python support files.
#
#--------------------------------------------------------------------#

#-----Set up---------------------------------------------------------#

# This section imports standard Python 3 modules sufficient to
# complete this assignment.  Don't change any of the code in this
# section, but you are free to import other Python 3 modules
# to support your solution, provided they are standard ones that
# are already supplied by default as part of a normal Python/IDLE
# installation.
#
# However, you may NOT use any Python modules that need to be
# downloaded and installed separately, such as "Beautiful Soup" or
# "Pillow", because the markers will not have access to such modules
# and will not be able to run your code.  Only modules that are part
# of a standard Python 3 installation may be used.

# A function for exiting the program immediately (renamed
# because "exit" is already a standard Python function).
from sys import exit as abort

# Some standard Tkinter functions.  [You WILL need to use
# SOME of these functions in your solution.]  You may also
# import other widgets from the "tkinter" module, provided they
# are standard ones and don't need to be downloaded and installed
# separately.  (NB: Although you can import individual widgets
# from the "tkinter.tkk" module, DON'T import ALL of them
# using a "*" wildcard because the "tkinter.tkk" module
# includes alternative versions of standard widgets
# like "Label" which leads to confusion.  If you want to use
# a widget from the tkinter.ttk module name it explicitly,
# as is done below for the progress bar widget.)
from tkinter import *
from tkinter.scrolledtext import ScrolledText
from tkinter.ttk import Progressbar

# Functions for finding occurrences of a pattern defined
# via a regular expression.  [You do not necessarily need to
# use these functions in your solution, because the problem
# may be solvable with the string "find" function, but it will
# be difficult to produce a concise and robust solution
# without using regular expressions.]
from re import *

# All the standard SQLite database functions.  [You WILL need
# to use some of these in your solution.]
from sqlite3 import *


#-----Validity Check-------------------------------------------------#
#
# This section confirms that the student has declared their
# authorship.  You must NOT change any of the code below.
#

if not isinstance(student_number, int):
    print('\nUnable to run: No student number supplied',
          '(must be an integer)\n')
    abort()
if not isinstance(student_name, str):
    print('\nUnable to run: No student name supplied',
          '(must be a character string)\n')
    abort()
#--------------------------------------------------------------------#




#-----Dummy Data----------------------------------------------#
#
# Below is data that you can use in your solution for Part A to
# substitute for database data that you will access and use in Part B.
movies_data = [
    {"title": "Inception", "lead_actor": "Leonardo DiCaprio", "director": "Christopher Nolan", "description": "Dom Cobb (Leonardo DiCaprio) is a skilled thief, the absolute best in extraction: stealing valuable secrets from within dreams. His talent makes him a coveted player in espionage but has cost him dearly."},
    {"title": "The Shawshank Redemption", "lead_actor": "Tim Robbins", "director": "Frank Darabont", "description": "Andy Dufresne (Tim Robbins), wrongly imprisoned for murder, forms bonds and finds redemption through perseverance and humanity."},
    {"title": "The Godfather", "lead_actor": "Marlon Brando", "director": "Francis Ford Coppola", "description": "Patriarch Vito Corleone (Marlon Brando) transfers control of his criminal empire to his reluctant son, Michael, exploring power, loyalty, and betrayal."},
    {"title": "The Dark Knight", "lead_actor": "Christian Bale", "director": "Christopher Nolan", "description": "Batman (Christian Bale), with allies Gordon and Dent, confronts chaos embodied by the Joker, testing the limits of heroism."},
    {"title": "Pulp Fiction", "lead_actor": "John Travolta", "director": "Quentin Tarantino", "description": "Interwoven stories of mobsters Vincent (John Travolta), Jules, Mia, and Butch, with sharp dialogue, dark humor, and intense violence."},
    {"title": "Forrest Gump", "lead_actor": "Tom Hanks", "director": "Robert Zemeckis", "description": "Forrest Gump (Tom Hanks), slow-witted yet kindhearted, unwittingly influences historical events and longs for his childhood love, Jenny."},
    {"title": "Fight Club", "lead_actor": "Brad Pitt", "director": "David Fincher", "description": "An insomniac and Tyler Durden (Brad Pitt) create an underground fight club, which spirals into a revolutionary movement."},
    {"title": "The Matrix", "lead_actor": "Keanu Reeves", "director": "The Wachowskis", "description": "Neo (Keanu Reeves), a hacker, learns reality is an illusion and joins a rebellion to free humanity from machine control."},
    {"title": "Gladiator", "lead_actor": "Russell Crowe", "director": "Ridley Scott", "description": "Maximus (Russell Crowe), betrayed Roman general, fights as a gladiator seeking vengeance against corrupt emperor Commodus."},
    {"title": "Interstellar", "lead_actor": "Matthew McConaughey", "director": "Christopher Nolan", "description": "Explorer Cooper (Matthew McConaughey) travels through a wormhole, battling time and space to ensure humanity's survival."},
    {"title": "Titanic", "lead_actor": "Leonardo DiCaprio", "director": "James Cameron", "description": "Jack (Leonardo DiCaprio) and Rose, from different worlds, fall in love aboard the ill-fated Titanic, fighting class divisions and disaster."},
    {"title": "Avatar", "lead_actor": "Sam Worthington", "director": "James Cameron", "description": "Marine Jake Sully (Sam Worthington) infiltrates Pandora's native Na'vi but becomes their defender against human exploitation."},
    {"title": "Jurassic Park", "lead_actor": "Sam Neill", "director": "Steven Spielberg", "description": "Scientists Alan Grant (Sam Neill) and team fight for survival when cloned dinosaurs run amok in a theme park gone wrong."},
    {"title": "The Lion King", "lead_actor": "Matthew Broderick", "director": "Roger Allers", "description": "Simba (Matthew Broderick), exiled lion prince, learns responsibility and courage to reclaim his rightful throne."},
    {"title": "Saving Private Ryan", "lead_actor": "Tom Hanks", "director": "Steven Spielberg", "description": "Captain Miller (Tom Hanks) and his soldiers undertake a dangerous WWII mission to rescue Private Ryan behind enemy lines."},
    {"title": "Braveheart", "lead_actor": "Mel Gibson", "director": "Mel Gibson", "description": "William Wallace (Mel Gibson) leads a fierce rebellion against English oppression in medieval Scotland, fighting passionately for freedom."},
    {"title": "The Departed", "lead_actor": "Leonardo DiCaprio", "director": "Martin Scorsese", "description": "Undercover cop Billy Costigan (Leonardo DiCaprio) infiltrates crime syndicates while dealing with betrayal and deception in Boston."},
    {"title": "Whiplash", "lead_actor": "Miles Teller", "director": "Damien Chazelle", "description": "Andrew (Miles Teller), driven jazz drummer, battles intense psychological warfare with his ruthless instructor to achieve greatness."},
    {"title": "Parasite", "lead_actor": "Song Kang-ho", "director": "Bong Joon-ho", "description": "The impoverished Kim family cunningly infiltrates a wealthy household, leading to shocking, unforeseen consequences."},
    {"title": "1917", "lead_actor": "George MacKay", "director": "Sam Mendes", "description": "Two WWI soldiers (George MacKay and Dean-Charles Chapman) must deliver an urgent message across enemy lines to avert disaster."},
    {"title": "Django Unchained", "lead_actor": "Jamie Foxx", "director": "Quentin Tarantino", "description": "Freed slave Django (Jamie Foxx) teams up with bounty hunter Schultz to rescue his wife from a ruthless plantation owner."},
    {"title": "The Prestige", "lead_actor": "Hugh Jackman", "director": "Christopher Nolan", "description": "Rival magicians (Hugh Jackman and Christian Bale) obsessively compete to create the ultimate illusion, with devastating consequences."},
    {"title": "La La Land", "lead_actor": "Ryan Gosling", "director": "Damien Chazelle", "description": "Aspiring actress Mia and jazz musician Sebastian fall in love but struggle to reconcile their dreams and their relationship."}
]


main_window = Tk()
main_window.title("Movision Search") #change the title of the GUI
main_window.geometry("500x600")  #change the size of the geometry so that it can fit for all the function of the app.


#-----Student's Solution---------------------------------------------#
# Put your solution below.
# As a starting point, you should consider defining functions for:
# - Cleaning Text
# - Searching Movies
# - Displaying Movie Details
# - Interface Setup for Application Branding
# - Interface Setup for Search Input
# - Interface Setup for Status Label(s)
# - Interface Setup for the Search Results area
# - Interface Setup for the Movie Details area

def clean_text(text): #Clean the text before finishing the search movie function 
    return sub(r'[^\w\d ]','',text).lower() #clear all the commas,etc and make it lower 

def search_movies(event = None): #Get the keyword from the user and search for the movies in the database.
    #Clean the old list and then get the keyword from the user
    movie_list.delete(0, END) 
    keyword = clean_text(search_bar.get())
    count_movies=  0
    #Search for the movie in the data, the list box will show users the name of all the movies that appear in the database. There is also a search status showing the user all the name of the movies.
    for movie in movies_data:
        if (keyword in movie['title'].lower() or keyword in movie['lead_actor'].lower() or keyword in movie['director'].lower() or keyword in movie["description"].lower()):
            movie_list.insert(END,movie["title"])
            count_movies += 1
    search_status.config(text=f"Number of result: {count_movies} movies found")

def display_movie_details(event):#Display all the information of the movies that the user select.
    selected_movie_index = movie_list.curselection() #Collect the selected movies from the user.
    #If the movies is selected, the movie text will show all the information of the movies including the title, lead author, director, and description.
    if selected_movie_index:
        # Get the title of the selected movie from the listbox
        selected_title = movie_list.get(selected_movie_index[0])
        # Find the corresponding movie data in the movies_data list by its title
        selected_movie = None
        for movie in movies_data:
            if movie["title"] == selected_title: #Finds the correct movie dictionary using the title, if it is found then break out of the string.
                selected_movie = movie
                break
        # Display details if the movie data was found
        if selected_movie:
            movie_text.delete(1.0, END)
            movie_text.insert(END, f"Title: {selected_movie['title']}\n")
            movie_text.insert(END, f"Lead Actor: {selected_movie['lead_actor']}\n")
            movie_text.insert(END, f"Director: {selected_movie['director']}\n\n")
            movie_text.insert(END, f"Description: {selected_movie['description']}\n")
    else:
        # Clear the details if nothing is selected (e.g., listbox is empty)
        movie_text.delete(1.0, END)

#Create the logo for the Movision Media search
img = PhotoImage(file="images.png")
logo = Label(main_window,text = "Movision Media",font=("Garamond",25,'bold'),image=img,compound='left')
logo.pack(pady = 10)
#Create the search bar and search button for the fucntion. The user can type in the keyword they want to search for the information of the movies and then click the Search button to search for the movies they want.
search_function = Frame(main_window) #Put both the search bar and search button in the same frame.
search_bar = Entry(search_function,width= 40)
search_bar.pack(side = 'left',pady = 10, padx = 10)
search_bar.bind('<Return>', search_movies) #User can either press Enter or press Search to look for the movies
search_button = Button(search_function,text = "Search",command = search_movies) #The user will click on the button to search for the movies they want
search_button.pack(side = 'left',pady = 10, padx = 5)
search_function.pack()

#The search status will show how many movies can be found from the keyword that the user has entered. There will be a default message before the user type in the keyword
search_status  = Label(text ="Enter a search item to find the movies.") #Show the default message of the status before user begins searching for the movies they want.
search_status.pack()

#Show the list of movies after searching for the word in a Listbox and the user can use the scrollbar to look for the full list of the movies that are displayed in the listbox after the user have finished their search.
listbox_items = Frame(main_window)
movie_list = Listbox(listbox_items,width=40, height=4)
movie_list.pack(side='left', fill='both', expand=True)
scrollbar = Scrollbar(listbox_items, orient='vertical', command=movie_list.yview) #The user can use the scrollbar to look for all the movies that they have looked for if the list is too long
scrollbar.pack(side='left', fill='y')
movie_list.config(yscrollcommand=scrollbar.set)
movie_list.bind('<<ListboxSelect>>', display_movie_details) #User can select any movies that they want in the search results that they have created.
listbox_items.pack(fill='both', expand=True,pady = 10,padx=15)

#Show the information for the movie when the user click on the movie in the movie listbox and search for the movie. The user can also use the scrollbar to look for all the information if the list is too long.
movie_information = Frame(main_window)
movie_text = Text(movie_information, wrap='word',width=80, height=15)
movie_text.pack(side='left', fill='both', expand=True)
text_scroll = Scrollbar(movie_information, orient='vertical',command=movie_text.yview) #The user can use the text scroll bar to look for the information of the movie that they have selected if it is too long
text_scroll.pack(side='left', fill='y')
movie_text.config(yscrollcommand=text_scroll.set)
text_scroll.config(command=movie_text.yview)
movie_information.pack(fill='both', expand=True,padx= 15)

#Finally, the main window will display all the widgets and functions 
main_window.mainloop()